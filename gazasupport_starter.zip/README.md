# Gaza Support static site

This is a simple static site for the Gaza Support campaign.

## How to use
1. Replace `https://YOUR-NGO-CAMPAIGN-LINK` in `index.html` with the real campaign URL or embed the NGO's iframe where indicated.
2. Deploy via Cloudflare Pages connected to this repository (Framework: None, Build command: empty, Output directory: `/`).

## Editing content
- Home copy: `index.html`
- Updates blog: `updates.html` (add new `<article>` blocks)
- Policies: `privacy.html`, `terms.html`
- Styles: `styles.css`
